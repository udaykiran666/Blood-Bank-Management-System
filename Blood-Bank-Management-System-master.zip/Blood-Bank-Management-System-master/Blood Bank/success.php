<?php
echo 'you have successfully registered';


?>