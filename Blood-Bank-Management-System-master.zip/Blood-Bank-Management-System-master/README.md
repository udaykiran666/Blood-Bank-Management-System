# Blood-Bank-Management-System
This is a website based on blood bank management system.The website is mainly made with php,Mysql,Html,Css,Javascript etc.

Full Working of the website is explained through  a video on Youtube.

Youtube Link-https://www.youtube.com/watch?v=JlYP2Upe_X8
